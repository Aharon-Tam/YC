﻿using System;
using System.Collections.Generic;
//using Excel = Microsoft.Office.Interop.Excel;

namespace LiborYieldCurve
{
  using System.ComponentModel;
  using System.Data;
  using System.Linq;
  using System.Reflection;

  using ClosedXML.Excel;

  using ExcelLibrary.SpreadSheet;

  using NPOI.SS.Formula;

  public static class Extensions
  {
    public static bool IsMonday(this DayOfWeek wkd)
    {
      return wkd == DayOfWeek.Monday;
    }

    public static bool IsFriday(this DayOfWeek wkd)
    {
      return wkd == DayOfWeek.Friday;
    }

    public static bool IsThursday(this DayOfWeek wkd)
    {
      return wkd == DayOfWeek.Thursday;
    }

    public static bool IsSaturday(this DayOfWeek wkd)
    {
      return wkd == DayOfWeek.Saturday;
    }

    public static bool IsSunday(this DayOfWeek wkd)
    {
      return wkd == DayOfWeek.Sunday;
    }

    public static int ToInteger(this string numb)
    {
      return Convert.ToInt32(numb);
    }

    public static double ToDouble(this string strNumb)
    {
      if (double.TryParse(strNumb, out var value))
      {
        return value;
      }
      return 0.0;
    }

    public static DataTable ToDataTable<T>(this IList<T> data)
    {
      PropertyDescriptorCollection properties =
        TypeDescriptor.GetProperties(typeof(T));
      DataTable table = new DataTable();
      foreach (PropertyDescriptor prop in properties)
        table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
      foreach (T item in data)
      {
        var row = table.NewRow();
        foreach (PropertyDescriptor prop in properties)
          row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
        table.Rows.Add(row);
      }
      return table;
    }

    public static DataTable ToDataTable2<T>(this List<T> items)
    {
      DataTable dataTable = new DataTable(typeof(T).Name);
      //Get all the properties
      PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
      foreach (PropertyInfo prop in Props)
      {
        //Setting column names as Property names
        dataTable.Columns.Add(prop.Name);
      }
      foreach (T item in items)
      {
        var values = new object[Props.Length];
        for (int i = 0; i < Props.Length; i++)
        {
          //inserting property values to datatable rows
          values[i] = Props[i].GetValue(item, null);
        }
        dataTable.Rows.Add(values);
      }
      //put a breakpoint here and check datatable
      return dataTable;
    }

    public static DataTable ToDataTable3<T>(this List<T> list, string tableName = "MyTable")
    {
      DataTable dt = new DataTable(tableName);

      foreach (PropertyInfo info in typeof(T).GetProperties())
      {
        dt.Columns.Add(new DataColumn(info.Name, Nullable.GetUnderlyingType(info.PropertyType) ?? info.PropertyType));
      }
      foreach (T t in list)
      {
        DataRow row = dt.NewRow();
        foreach (PropertyInfo info in typeof(T).GetProperties())
        {
          row[info.Name] = info.GetValue(t, null) ?? DBNull.Value;
        }
        dt.Rows.Add(row);
      }
      return dt;
    }

    public static void Print(this DataTable data)
    {
      Console.WriteLine();
      Dictionary<string, int> colWidths = new Dictionary<string, int>();

      foreach (DataColumn col in data.Columns)
      {
        Console.Write(col.ColumnName);
        var maxLabelSize = data.Rows.OfType<DataRow>()
          .Select(m => (m.Field<object>(col.ColumnName)?.ToString() ?? "").Length)
          .OrderByDescending(m => m).FirstOrDefault();

        colWidths.Add(col.ColumnName, maxLabelSize);
        for (int i = 0; i < maxLabelSize - col.ColumnName.Length + 10; i++) Console.Write(" ");
      }

      Console.WriteLine();

      foreach (DataRow dataRow in data.Rows)
      {
        for (int j = 0; j < dataRow.ItemArray.Length; j++)
        {
          Console.Write(dataRow.ItemArray[j]);
          for (int i = 0; i < colWidths[data.Columns[j].ColumnName] - dataRow.ItemArray[j].ToString().Length + 10; i++) Console.Write(" ");
        }
        Console.WriteLine();
      }
    }

    public static void Print(this List<int> data, string title = "")
    {
      Console.WriteLine();
      if (!string.IsNullOrEmpty(title))
      {
        Console.WriteLine(title);
      }

      Console.Write("[ ");
      foreach (var value in data)
      {
        Console.Write($"{value} ");
      }
      Console.Write("]");
      Console.WriteLine();
    }

    public static void Print(this List<DateTime> data, string title = "")
    {
      Console.WriteLine();
      if (!string.IsNullOrEmpty(title))
      {
        Console.WriteLine(title);
      }

      Console.Write("[ ");
      foreach (var value in data)
      {
        Console.Write($"{value:yyyy-MM-dd} ");
      }
      Console.Write("]");
      Console.WriteLine();
    }

    public static void Print(this List<double> data, string title = "")
    {
      Console.WriteLine();
      if (!string.IsNullOrEmpty(title))
      {
        Console.WriteLine(title);
      }

      Console.Write("[ ");
      foreach (var value in data)
      {
        Console.Write($"{value:0.######} ");
      }
      Console.Write("]");
      Console.WriteLine();
    }

    public static void Print(this List<object> data, string title = "")
    {
      Console.WriteLine();
      if (!string.IsNullOrEmpty(title))
      {
        Console.WriteLine(title);
      }

      Console.Write("[ ");
      foreach (var value in data)
      {
        if (value is double)
          Console.Write($"{value:0.######} ");
        else
          Console.Write($"{value} ");
      }

      Console.Write("]");
      Console.WriteLine();
    }

    public static DateTime ToDateTime(this object @this)
    {
      return Convert.ToDateTime(@this);
    }

    public static void ExportToExcel(this DataTable tbl, string excelFilePath, string excelSheetName = null)
    {
      try
      {
        var sheetName = "Sheet1";
        if (!string.IsNullOrEmpty(excelSheetName))
          sheetName = excelSheetName;

        using var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add(sheetName);

        // column headings
        for (var j = 0; j < tbl.Columns.Count; j++)
        {
          var columnName = tbl.Columns[j].ColumnName;
          worksheet.Cell(1, j + 1).Value = columnName;
        }

        var i = 0;
        while (i < tbl.Rows.Count)
        {
          // to do: format datetime values before printing
          for (var j = 0; j < tbl.Columns.Count; j++)
          {
            var rowValue = tbl.Rows[i][j] ?? string.Empty;
            worksheet.Cell(i + 2, j + 1).Value = rowValue;
          }

          ++i;
        }

        workbook.SaveAs(excelFilePath);
      }
      catch (Exception ex)
      {
        throw new Exception("ExportToExcel: \n" + ex.Message);
      }
    }
  }
}
