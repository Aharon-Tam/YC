﻿using System;

namespace LiborYieldCurve
{
  internal class Program
  {
    static void Main(string[] args)
    {
      var yc = new YieldCurve();

      yc.GetSwapCurveData();
      yc.SetDatesForTenors();
      yc.YearFractionsForTenors();
      yc.ZeroRates();

      //Console.ReadKey();
    }
  }
}
