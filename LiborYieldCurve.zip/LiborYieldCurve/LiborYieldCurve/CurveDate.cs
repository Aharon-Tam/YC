﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LiborYieldCurve
{
  public class CurveDate : CountryHoliday
  {
    public bool IsWeekend(DateTime date)
    {
      var wkd = date.DayOfWeek;
      return wkd.IsSaturday() || wkd.IsSunday();
    }

    public DateTime AddBusinessDays(DateTime date, int days, string calendar, string busyDayConv)
    {
      var nextDate = date;

      int sign = Math.Sign(days);
      var unsignedDays = Math.Abs(days);
      for (var i = 0; i < unsignedDays; i++)
      {
        do
        {
          nextDate = nextDate.AddDays(sign);
        } while ( IsWeekend(nextDate) || IsHoliday(nextDate, calendar));
      }
      return nextDate;
    }

    public DateTime AddBusinessMonths(DateTime date, int months, string calendar, string busydayconv)
    {
      if (months == 48)
      {

      }
      var nextDate = date;

      int sign = Math.Sign(months);
      nextDate = nextDate.AddMonths(months);
      while (IsWeekend(nextDate) || IsHoliday(nextDate, calendar))
      {
        nextDate = nextDate.AddDays(sign);
      }

      return nextDate;
    }

    public DateTime AddBusinessYears(DateTime date, int years, string calendar, string busydayconv)
    {
      var nextDate = date;

      int sign = Math.Sign(years);
      nextDate = nextDate.AddYears(years);
      while (IsWeekend(nextDate) || IsHoliday(nextDate, calendar))
      {
        nextDate = nextDate.AddDays(sign);
      }

      return nextDate;
    }

    public double YearFrac(DateTime date1, DateTime date2, string dayCountConvention)
    {
      var deltaFraction = 0.0d;
      TimeSpan delta;

      switch (dayCountConvention)
      {
        case "ACTACT":
        case "Thirty360":
          break;
        case "ACT365":
          delta = date2 - date1;
          deltaFraction = delta.Days / 365.0;
          break;
        case "ACT360":
          delta = date2 - date1;
          deltaFraction = delta.Days / 360.0;
          break;
        default:
          delta = date2 - date1;
          deltaFraction = delta.Days / 360.0;
          break;
      }
      return deltaFraction;
    }
  }
}
