﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LiborYieldCurve
{
  internal class Tenor
  {
    public string Value { get; set; }
  }
}
