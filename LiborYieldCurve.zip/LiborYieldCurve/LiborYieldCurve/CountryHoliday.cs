﻿using System;

namespace LiborYieldCurve
{
  using System.Runtime.InteropServices.WindowsRuntime;

  using Nager.Date;

  public class CountryHoliday
  {
    public bool IsPublicHoliday(DateTime date, string calendar)
    {
      if (!Enum.TryParse(calendar, out CountryCode countryCode))
      {
        return false;
      }

      return DateSystem.IsPublicHoliday(date, countryCode);
    }

    public bool IsHoliday(DateTime date, string calendar)
    {
      var wkd = date.DayOfWeek;
      var m = date.Month;
      var d = date.Day;

      if (wkd.IsSaturday() || wkd.IsSunday())
        return false;

      switch (calendar)
      {
        case "NY":
          // January 1
          if (  (m == 1 && d == 1) || (m == 12 && d == 31 && wkd.IsFriday()) || (m == 1 && d == 2 && wkd.IsMonday()) )
            return true;

          // Martin Luther King, third Monday of January
          if (m == 1 && wkd == DayOfWeek.Monday && (d > 14 && d < 22))
            return true;

          // Washington's Birthday, third Monday of February
          if (m == 2 && wkd == DayOfWeek.Monday && (d > 14 && d < 22))
            return true;

          // Memorial Day, last Monday of May
          if (m == 5 && wkd == DayOfWeek.Monday && d > 24)
            return true;

          // Independence Day, July 4
          if ((m == 7 && d == 4) || (m == 7 && d == 3 && wkd == DayOfWeek.Friday) || (m == 7 && d == 5 && wkd == DayOfWeek.Monday))
            return true;

          // Labor Day, the first Monday of September
          if (m == 9 && wkd == DayOfWeek.Monday && d < 8)
            return true;

          // Columbus Day, second Monday of October
          if (m == 10 && wkd == DayOfWeek.Monday && (d > 7 && d < 15))
            return true;

          // Veterans Day, November 11
          if ((m == 11 && d == 11) || (m == 11 && d == 10 && wkd == DayOfWeek.Friday) || (m == 11 && d == 12 && wkd == DayOfWeek.Monday))
            return true;

          // Thanksgiving Day, fourth Thursday of November
          if (m == 11 && wkd == DayOfWeek.Thursday && (d > 21 && d < 29))
            return true;

          // Christmas Day, December 25
          if ((m == 12 && d == 25) || (m == 12 && d == 24 && wkd == DayOfWeek.Friday) || (m == 12 && d == 26 && wkd == DayOfWeek.Monday))
            return true;
          break;
      }
    
      return false;
    }
  }
}
