﻿using System.Collections.Generic;

namespace LiborYieldCurve
{
  using System;
  using System.Data;
  using System.Diagnostics;
  using System.IO;
  using System.Linq;

  using MathNet.Numerics.Interpolation;

  using Nager.Date;

  using NPOI.HSSF.Record;
  using NPOI.SS.UserModel;
  using NPOI.XSSF.UserModel;

  using TinySpline;

  public class YieldCurve : CurveDate
  {
    private DataTable discountFactorCurveTbl;
    private DataTable curveParametersTbl;

    public void GetSwapCurveData()
    {
      var date = DateTime.Now;
      
      var check = IsHoliday(date, "US");

      var fileName = @".\Data\swapcurvedata.xlsx";
      var sheetName = "swapcurve";
      // var columnNameIndex = "Tenor";
      var excelHelper = new ExcelHelper();
      discountFactorCurveTbl = excelHelper.ReadExcel(fileName, sheetName);
      discountFactorCurveTbl.Print();

      sheetName = "curveparams";
      curveParametersTbl = excelHelper.ReadExcel(fileName, sheetName);
      var today = DateTime.Now.ToString("yyyy-MM-dd");

      DataRow dr = curveParametersTbl.AsEnumerable().First();
      dr["Date"] = today;
      curveParametersTbl.Print();

      var busDayConv = dr["BusDayConv"].ToString();
      var calendar = dr["Calendar"].ToString();

      var curveDate = dr["Date"].ToDateTime();

      while (IsWeekend(curveDate) || IsHoliday(curveDate, calendar))
      {
        curveDate = curveDate.AddDays(1);
      }

      var curveSettleDays = Convert.ToInt32(dr["SettleDays"].ToString());
      var curveSettleDate = AddBusinessDays(curveDate, curveSettleDays, calendar, busDayConv);

      if (!curveParametersTbl.Columns.Contains("SettleDate"))
      {
        var settleDateColumn = new DataColumn("SettleDate", typeof(System.String));
        curveParametersTbl.Columns.Add(settleDateColumn);
      }
      dr = curveParametersTbl.AsEnumerable().First();
      dr["SettleDate"] = curveSettleDate.ToString("yyyy-MM-dd");

      curveParametersTbl.AcceptChanges();

      curveParametersTbl.Print();
    }

    public void SetDatesForTenors()
    {
      var dr = curveParametersTbl.AsEnumerable().First();
      var curveSettleDate = dr["SettleDate"].ToDateTime();
      var busDayConv = dr["BusDayConv"].ToString();
      var calendar = dr["Calendar"].ToString();

      if (!discountFactorCurveTbl.Columns.Contains("Date"))
      {
        var settleDateColumn = new DataColumn("Date", typeof(System.String));
        discountFactorCurveTbl.Columns.Add(settleDateColumn);
      }

      //var overNightDate = AddBusinessDays(curveSettleDate, 1, calendar, busDayConv);
      //var oneWeekDate = AddBusinessDays(curveSettleDate, 5, calendar, busDayConv);

      //discountFactorCurveTbl.AsEnumerable().Where(x => x.Field<string>("Tenor") == "ON")
      //  .ToList()
      //  .ForEach(swapDataRow =>
      //      {
      //        swapDataRow["Date"] = overNightDate.ToString("yyyy-MM-dd");
      //      });

      //discountFactorCurveTbl.AsEnumerable().Where(x => x.Field<string>("Tenor") == "1W")
      //  .ToList()
      //  .ForEach(swapDataRow =>
      //    {
      //      swapDataRow["Date"] = oneWeekDate.ToString("yyyy-MM-dd");
      //    });

      discountFactorCurveTbl.AsEnumerable()
        .ToList()
        .ForEach(dfDataRow =>
          {
            var tenor = dfDataRow["Tenor"].ToString();
            if (tenor == null) return;

            if (tenor.Equals("ON"))
            {
              var overNightDate = AddBusinessDays(curveSettleDate, 1, calendar, busDayConv);
              dfDataRow["Date"] = overNightDate.ToString("yyyy-MM-dd");
            }
            else if (tenor.Equals("1W"))
            {
              var oneWeekDate = AddBusinessDays(curveSettleDate, 5, calendar, busDayConv);
              dfDataRow["Date"] = oneWeekDate.ToString("yyyy-MM-dd");
            }
            else
            {
              var last = tenor.Last();
              var numb = tenor.Substring(0, tenor.Length - 1).ToInteger();
              if (last == 'M')
              {
                var targetDate = AddBusinessMonths(curveSettleDate, numb, calendar, busDayConv);
                dfDataRow["Date"] = targetDate.ToString("yyyy-MM-dd");
              }
              else if (last == 'Y')
              {
                if (numb == 4)
                {

                }
                var targetDate = AddBusinessYears(curveSettleDate, numb, calendar, busDayConv);
                dfDataRow["Date"] = targetDate.ToString("yyyy-MM-dd");
              }
            }
          });

      discountFactorCurveTbl.AcceptChanges();

      discountFactorCurveTbl.Print();
    }

    public void YearFractionsForTenors()
    {
      var dr = curveParametersTbl.AsEnumerable().First();
      var curveSettleDate = dr["SettleDate"].ToDateTime();

      if (!discountFactorCurveTbl.Columns.Contains("YearFraction"))
      {
        var yearFractionColumn = new DataColumn("YearFraction", typeof(System.Double));
        discountFactorCurveTbl.Columns.Add(yearFractionColumn);
      }

      if (!discountFactorCurveTbl.Columns.Contains("CumYearFraction"))
      {
        var yearFractionColumn = new DataColumn("CumYearFraction", typeof(System.Double));
        discountFactorCurveTbl.Columns.Add(yearFractionColumn);
      }

      var rowCount = 0;
      var prevDateTime = DateTime.Now;

      discountFactorCurveTbl.AsEnumerable()
        .ToList()
        .ForEach(dfDataRow =>
          {
            var dayCountConv = dfDataRow["Daycount"].ToString();
            var nextDate = dfDataRow["Date"].ToString().ToDateTime();
            if (rowCount++ == 0)
            {
              var frac = YearFrac(curveSettleDate, nextDate, dayCountConv);
              dfDataRow["YearFraction"] = frac;
            }
            else
            {
              var frac = YearFrac(prevDateTime, nextDate, dayCountConv);
              dfDataRow["YearFraction"] = frac;
            }

            var cumFrac = YearFrac(curveSettleDate, nextDate, dayCountConv);
            dfDataRow["CumYearFraction"] = cumFrac;
            prevDateTime = nextDate;

          });

      discountFactorCurveTbl.AcceptChanges();

      discountFactorCurveTbl.Print();
    }

    public void ZeroRates()
    {
      if (!discountFactorCurveTbl.Columns.Contains("ZeroRate"))
      {
        var yearFractionColumn = new DataColumn("ZeroRate", typeof(System.Double));
        discountFactorCurveTbl.Columns.Add(yearFractionColumn);
      }

      var prevZeroRate = 0.0;
      var prevCumYearFrac = 0.0;
      bool @break = false;
      var jRow = -1;
      var swapPoints = 0;

      discountFactorCurveTbl.AsEnumerable()
        .ToList()
        .ForEach(dfDataRow =>
          {
            ++jRow;
            if (@break) return;

            var instrType = dfDataRow["Type"].ToString();

            if (instrType == null) return;

            if ( instrType.Equals("Deposit"))
            {
              var swapRate = dfDataRow["SwapRate"].ToString().ToDouble();
              var cumYearFrac = dfDataRow["CumYearFraction"].ToString().ToDouble();

              var zeroRate = (1.0 / cumYearFrac) * Math.Log(1.0 + swapRate * cumYearFrac);

              dfDataRow["ZeroRate"] = zeroRate;

              prevZeroRate = zeroRate;
              prevCumYearFrac = cumYearFrac;

            }
            else if (instrType.Equals("EuroDollarFuture"))
            {
              var swapRate = dfDataRow["SwapRate"].ToString().ToDouble();
              var yearFrac = dfDataRow["YearFraction"].ToString().ToDouble();
              var cumYearFrac = dfDataRow["CumYearFraction"].ToString().ToDouble();

              var rateContinuous = 4 * Math.Log(1.0 + swapRate * yearFrac);
              var zeroRate = (rateContinuous * yearFrac + prevZeroRate * prevCumYearFrac) / cumYearFrac;
              dfDataRow["ZeroRate"] = zeroRate;

              prevZeroRate = zeroRate;
              prevCumYearFrac = cumYearFrac;
            }
            else
            {
              var sumProduct = 0.0;
              if (!instrType.Equals("Swap")) return;

              var frequency = dfDataRow["Frequency"].ToString();
              var tenor = dfDataRow["Tenor"].ToString();
              if (tenor == null) return;
              var term = tenor.Substring(0, tenor.Length - 1).ToInteger();

              var cumYearFractions = discountFactorCurveTbl.AsEnumerable().Select(r => r.Field<double>("CumYearFraction")).ToList();
              var zeroRates1 = discountFactorCurveTbl.AsEnumerable().Select(r => r.Field<object>("ZeroRate")).ToList();

              var zeroRates = discountFactorCurveTbl.Rows.Cast<DataRow>().Select(r => Convert.ToString(r["ZeroRate"]).ToDouble()).ToList();

              Console.WriteLine($"Row: {jRow}");
              var x = cumYearFractions.Take(jRow).ToArray();
              var y = zeroRates.Take(jRow).ToArray();
              x.ToList().Print("--- Cum Year Fractions ---");
              y.ToList().Print("--- Zero Rates ---");

              var points = new List<double>();
              for (var ii = 0; ii < x.Length; ii++)
              {
                points.Add(x[ii]);
                points.Add(y[ii]);
              }

              var bSpline = BSpline.InterpolateCubicNatural(points, 2); // x => y or t => y

              var zeroTrack1 = CubicSpline.InterpolateNatural(x, y);
              var zeroTrack2 = CubicSpline.InterpolateAkima(x, y);
              var zeroTrack3 = CubicSpline.InterpolateAkimaSorted(x, y);
              var zeroTrack = CubicSpline.InterpolatePchipSorted(x, y);

              var swapRate = dfDataRow["SwapRate"].ToString().ToDouble();
              var cumYearFraction = dfDataRow["CumYearFraction"].ToString().ToDouble();
              var semiSwapRate = swapRate / 2.0;

              var swapYearFractions = SwapYearFractions(frequency, term);
              foreach (var swapYearFraction in swapYearFractions)
              {
                DeBoorNet net = bSpline.Bisect(swapYearFraction);
                var result = net.Result;
                var swapYfZeroRate = result[1];

                //--var swapYfZeroRate = zeroTrack.Interpolate(swapYearFraction);
                var swapYfRate = Math.Exp(-swapYfZeroRate * swapYearFraction);
                sumProduct += semiSwapRate * swapYfRate;
              }

              var zeroRate = (-1 * Math.Log(1.0 - sumProduct) / (1.0 + semiSwapRate)) / cumYearFraction;
              dfDataRow["ZeroRate"] = zeroRate;
              swapPoints++;

              if (swapPoints > 2)
                @break = true;
            }
          });

      discountFactorCurveTbl.AcceptChanges();
      discountFactorCurveTbl.Print();

      var now = DateTime.Now;
      var timestamp = now.ToString("yyyyMMdd_hhssmm");
      var fileout = @$"C:\CS\Spline\Data\YieldCurve_{timestamp}.xlsx";

      discountFactorCurveTbl.ExportToExcel(fileout, "YieldCurve");

      OpenMicrosoftExcel(fileout);
    }

    private static void OpenMicrosoftExcel(string fileName)
    {
      var startInfo = new ProcessStartInfo();
      startInfo.FileName = @"C:\Program Files (x86)\Microsoft Office\root\Office16\EXCEL.EXE";
      startInfo.Arguments = fileName;
      Process.Start(startInfo);
    }

    private List<double> SwapYearFractions(string frequency, int term)
    {

      var dr = curveParametersTbl.AsEnumerable().First();
      var curveSettleDate = dr["SettleDate"].ToDateTime();
      var busDayConv = dr["BusDayConv"].ToString();
      var calendar = dr["Calendar"].ToString();

      var period = 0.5;
      if (frequency.Equals("S"))
        period = 0.5;
      else if (frequency.Equals("Q"))
        period = 0.25;

      var swapMonths = new List<int>();

      for (var ii = 1; ii < 2 * term; ii++)
      {
        swapMonths.Add((int)(12* period * ii));
      }

      Console.WriteLine("--- Swap Months ---");
      swapMonths.Print();

      var swapDates = swapMonths.Select(swapMonth => AddBusinessMonths(curveSettleDate, swapMonth, calendar, busDayConv)).ToList();

      Console.WriteLine("--- Swap Dates ---");
      swapDates.Print();

      var swapYearFractions = swapDates.Select(swapDate => YearFrac(curveSettleDate, swapDate, "ACT/360")).ToList();

      Console.WriteLine("--- Swap Year Fractions ---");
      swapYearFractions.Print();

      return swapYearFractions;
    }
  }
}
