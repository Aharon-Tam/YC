﻿using System.Collections.Generic;

namespace LiborYieldCurve
{
  using System;
  using System.Collections;
  using System.Data;
  using System.IO;
  using System.Linq;

  using NPOI.HSSF.UserModel;
  using NPOI.SS.UserModel;
  using NPOI.XSSF.UserModel;

  public class ExcelHelper
  {
    public DataTable ReadExcel(string filePath, string sheetName)
    {
      DataTable dtTable = new DataTable();
      List<string> rowList = new List<string>();
      // find sheet #
      var sheetIndex = GetSheetIndexName(filePath, sheetName);
      if (sheetIndex == -1) return dtTable;

      ISheet sheet;
      using var stream = new FileStream(filePath, FileMode.Open);

      stream.Position = 0;
      XSSFWorkbook xssWorkbook = new XSSFWorkbook(stream);

      sheet = xssWorkbook.GetSheetAt(sheetIndex);
      IRow headerRow = sheet.GetRow(0);
      int cellCount = headerRow.LastCellNum;
      for (int j = 0; j < cellCount; j++)
      {
        ICell cell = headerRow.GetCell(j);
        if (cell == null || string.IsNullOrWhiteSpace(cell.ToString())) continue;
        {
          dtTable.Columns.Add(cell.ToString());
        }
      }
      for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++)
      {
        IRow row = sheet.GetRow(i);
        if (row == null) continue;
        if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;
        for (int j = row.FirstCellNum; j < cellCount; j++)
        {
          if (row.GetCell(j) != null)
          {
            if (!string.IsNullOrEmpty(row.GetCell(j).ToString()) && !string.IsNullOrWhiteSpace(row.GetCell(j).ToString()))
            {
              rowList.Add(row.GetCell(j).ToString());
            }
          }
        }
        if (rowList.Count > 0)
          dtTable.Rows.Add(rowList.ToArray());
        rowList.Clear();
      }

      return dtTable; // JsonConvert.SerializeObject(dtTable);
    }

    public DataTable ReadExcel(string filePath, string sheetName, string columnName)
    {
      DataTable dtTable = new DataTable();
      List<string> rowList = new List<string>();
      // find sheet #
      var sheetIndex = GetSheetIndexName(filePath, sheetName);
      if (sheetIndex == -1) return dtTable;

      ISheet sheet;
      using var stream = new FileStream(filePath, FileMode.Open);

      stream.Position = 0;
      XSSFWorkbook xssWorkbook = new XSSFWorkbook(stream);
   
      sheet = xssWorkbook.GetSheetAt(sheetIndex);
      IRow headerRow = sheet.GetRow(0);
      int cellCount = headerRow.LastCellNum;
      for (int j = 0; j < cellCount; j++)
      {
        ICell cell = headerRow.GetCell(j);
        if (cell == null || string.IsNullOrWhiteSpace(cell.ToString())) continue;
        {
          dtTable.Columns.Add(cell.ToString());
        }
      }
      for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++)
      {
        IRow row = sheet.GetRow(i);
        if (row == null) continue;
        if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;
        for (int j = row.FirstCellNum; j < cellCount; j++)
        {
          if (row.GetCell(j) != null)
          {
            if (!string.IsNullOrEmpty(row.GetCell(j).ToString()) && !string.IsNullOrWhiteSpace(row.GetCell(j).ToString()))
            {
              rowList.Add(row.GetCell(j).ToString());
            }
          }
        }
        if (rowList.Count > 0)
          dtTable.Rows.Add(rowList.ToArray());
        rowList.Clear();
      }

      List<string> items = dtTable.AsEnumerable().Select(r => r.Field<string>(columnName)).ToList();

      var dataTable = new DataTable();
      dataTable.Columns.Add(columnName);

      foreach (var item in items)
      {
        dataTable.Rows.Add(item);
      }

      // var tenors = dtTable.AsEnumerable().Select(r => r.Field<string>(columnName)).Select(x => new Tenor {Value = x}).ToList();

      // var dt = tenors.ToDataTable();
      // var converter = new ListToDataTableConverter();
      // DataTable dtOfColumns = converter.ToDataTable(objs);

      return dataTable; // JsonConvert.SerializeObject(dtTable);
    }

    private int GetSheetIndexName(string filePath, string sheetName)
    {
      byte[] fileBytes = File.ReadAllBytes(filePath);
      var excelStream = new MemoryStream(fileBytes);

      //get the uploaded file name  
      var fileName = Path.GetFileName(filePath);

      //get the extension of uploaded excel file  
      var fileExt = Path.GetExtension(fileName);

      if (fileExt == ".xls")
      {
        var hssfwb = new HSSFWorkbook(excelStream);

        for (var i = 0; i < hssfwb.NumberOfSheets; i++)
        {
          var currentSheetName = hssfwb.GetSheetName(i).Trim().Replace(" ", "").ToUpper();

          if (!string.IsNullOrEmpty(currentSheetName))
          {
            if (currentSheetName.Equals(sheetName.ToUpper())) return i;
          }
        }
      }
      else if (fileExt == ".xlsx")
      {
        var hssfwb = new XSSFWorkbook(excelStream);

        for (int i = 0; i < hssfwb.NumberOfSheets; i++)
        {
          var currentSheetName = hssfwb.GetSheetName(i).Trim().Replace(" ", "").ToUpper();

          if (!string.IsNullOrEmpty(currentSheetName))
          {
            if (currentSheetName.Equals(sheetName.ToUpper())) return i;
          }
        }
      }

      return -1;
    }

    private ArrayList GetSheetName(string filePath)
    {
      ArrayList arrayList = new ArrayList();
      try
      {
        FileStream readfile = new FileStream(filePath, FileMode.Open, FileAccess.Read);

        HSSFWorkbook hssfworkbook = new HSSFWorkbook(readfile);
        for (int i = 0; i < hssfworkbook.NumberOfSheets; i++)
        {
          arrayList.Add(hssfworkbook.GetSheetName(i));
        }
      }
      catch (Exception exception)
      {
        //wl.WriteLogs(exception.ToString());
      }
      return arrayList;
    }

    private List<string> GetSheetNames(string FilePath)
    {
      var oList = new List<string>();

      byte[] CSVBytes = File.ReadAllBytes(FilePath);
      var excelStream = new MemoryStream(CSVBytes);

      DataTable dt = new DataTable();

      //get the uploaded file name  
      string FileName = Path.GetFileName(FilePath);

      //get the extension of uploaded excel file  
      var FileExt = Path.GetExtension(FileName);

      if (FileExt == ".xls")
      {
        //HSSWorkBook object will read the Excel 97-2000 formats  
        HSSFWorkbook hssfwb = new HSSFWorkbook(excelStream);

        for (var i = 0; i < hssfwb.NumberOfSheets; i++)
        {
          var sheetName = hssfwb.GetSheetName(i).Trim().Replace(" ", "").ToUpper();

          if (!string.IsNullOrEmpty(sheetName))
          {
            oList.Add(sheetName);
          }
        }
      }
      else if (FileExt == ".xlsx")
      {
        //XSSFWorkBook will read 2007 Excel format  
        XSSFWorkbook hssfwb = new XSSFWorkbook(excelStream);

        for (int i = 0; i < hssfwb.NumberOfSheets; i++)
        {
          var sheetName = hssfwb.GetSheetName(i).Trim().Replace(" ", "").ToUpper();

          if (!string.IsNullOrEmpty(sheetName))
          {
            oList.Add(sheetName);
          }
        }
      }

      return oList;
    }

    public void WriteExcel(DataTable table, string filePath, string nameOfSheet = "")
    {
      // Lets converts our object data to Datatable for a simplified logic.
      // Datatable is most easy way to deal with complex datatypes for easy reading and formatting.

      using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);

      IWorkbook workbook = new XSSFWorkbook(); // for *.xlsx; HSSFWorkbook for *.xls
      var sheetName = "Sheet1";
      if (!string.IsNullOrEmpty(nameOfSheet)) sheetName = nameOfSheet;

      ISheet excelSheet = workbook.CreateSheet(sheetName);

      var columns = new List<string>();
      IRow row = excelSheet.CreateRow(0);
      int columnIndex = 0;

      foreach (System.Data.DataColumn column in table.Columns)
      {
        columns.Add(column.ColumnName);
        row.CreateCell(columnIndex).SetCellValue(column.ColumnName);
        columnIndex++;
      }

      int rowIndex = 1;
      foreach (DataRow dsrow in table.Rows)
      {
        row = excelSheet.CreateRow(rowIndex);
        int cellIndex = 0;
        foreach (var col in columns)
        {
          row.CreateCell(cellIndex).SetCellValue(dsrow[col].ToString());
          cellIndex++;
        }

        rowIndex++;
      }

      workbook.Write(fs);
    }

    //void WriteExcel()
    //{
    //  List<UserDetails> persons = new List<UserDetails>()
    //        {
    //            new UserDetails() {ID="1001", Name="ABCD", City ="City1", Country="USA"},
    //            new UserDetails() {ID="1002", Name="PQRS", City ="City2", Country="INDIA"},
    //            new UserDetails() {ID="1003", Name="XYZZ", City ="City3", Country="CHINA"},
    //            new UserDetails() {ID="1004", Name="LMNO", City ="City4", Country="UK"},
    //       };

    //  // Lets converts our object data to Datatable for a simplified logic.
    //  // Datatable is most easy way to deal with complex datatypes for easy reading and formatting.

    //  DataTable table = (DataTable)JsonConvert.DeserializeObject(JsonConvert.SerializeObject(persons), (typeof(DataTable)));
    //  var memoryStream = new MemoryStream();

    //  using (var fs = new FileStream("Result.xlsx", FileMode.Create, FileAccess.Write))
    //  {
    //    IWorkbook workbook = new XSSFWorkbook();
    //    ISheet excelSheet = workbook.CreateSheet("Sheet1");

    //    var columns = new List<string>();
    //    IRow row = excelSheet.CreateRow(0);
    //    int columnIndex = 0;

    //    foreach (System.Data.DataColumn column in table.Columns)
    //    {
    //      columns.Add(column.ColumnName);
    //      row.CreateCell(columnIndex).SetCellValue(column.ColumnName);
    //      columnIndex++;
    //    }

    //    int rowIndex = 1;
    //    foreach (DataRow dsrow in table.Rows)
    //    {
    //      row = excelSheet.CreateRow(rowIndex);
    //      int cellIndex = 0;
    //      foreach (String col in columns)
    //      {
    //        row.CreateCell(cellIndex).SetCellValue(dsrow[col].ToString());
    //        cellIndex++;
    //      }

    //      rowIndex++;
    //    }
    //    workbook.Write(fs);
    //  }
    //}
  }
}
