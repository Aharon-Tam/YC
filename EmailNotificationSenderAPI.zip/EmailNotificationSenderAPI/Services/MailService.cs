﻿using MimeKit;
using System.IO;
using System.Threading.Tasks;

using MailKit.Security;
using Microsoft.Extensions.Options;
using _101SendEmailNotificationDoNetCoreWebAPI.Settings;
using _101SendEmailNotificationDoNetCoreWebAPI.Model;

namespace _101SendEmailNotificationDoNetCoreWebAPI.Services
{
  using System;
  using System.Diagnostics;
  using System.Linq;
  using System.Net.Mail;

  using SmtpClient = MailKit.Net.Smtp.SmtpClient;

  public class MailService : IMailService
  {
    private readonly MailSettings mailSettings;

    public MailService(IOptions<MailSettings> mailSettings)
    {
      this.mailSettings = mailSettings.Value;
    }

    public async Task SendEmailAsync(MailRequest mailRequest)
    {
      //await SendEmailUsingNetMail(mailRequest);
      await SendEmailUsingMailKit(mailRequest);
    }

    private async Task SendEmailUsingMailKit(MailRequest mailRequest)
    {
      var email = CreateMimeMessageForMailKit(mailRequest);

      await SendMessageUsingMailKit(email);
    }

    private async Task SendEmailUsingNetMail(MailRequest mailRequest)
    {
      var email = CreateEmailMessage(mailRequest);

      await SendMessageUsingNetMail(email);
    }

    private MimeMessage CreateEmailMessage(MailRequest mailRequest)
    {
      var emailMessage = new MimeMessage();
      emailMessage.From.Add(new MailboxAddress("email", mailSettings.MailFrom));
      //emailMessage.To.AddRange(mailRequest.ToEmail);
      emailMessage.To.Add(MailboxAddress.Parse(mailRequest.ToEmail));
      emailMessage.Subject = mailRequest.Subject;

      var htmlContent = $"<h2 style='color:red;'>{mailRequest.Body}</h2>";

      var bodyBuilder = new BodyBuilder { HtmlBody = htmlContent };
      if (mailRequest.Attachments != null && mailRequest.Attachments.Any())
      {
        byte[] fileBytes;
        foreach (var attachment in mailRequest.Attachments)
        {
          using (var ms = new MemoryStream())
          {
            attachment.CopyTo(ms);
            fileBytes = ms.ToArray();
          }
          bodyBuilder.Attachments.Add(attachment.FileName, fileBytes, ContentType.Parse(attachment.ContentType));
        }
      }
      emailMessage.Body = bodyBuilder.ToMessageBody();
      return emailMessage;
    }

    private MimeMessage CreateMimeMessageForMailKit(MailRequest mailRequest)
    {
      var email = new MimeMessage();
      email.Sender = MailboxAddress.Parse(mailSettings.MailFrom);
      email.To.Add(MailboxAddress.Parse(mailRequest.ToEmail));
      email.Subject = mailRequest.Subject;
      var builder = new BodyBuilder();
      if (mailRequest.Attachments != null)
      {
        byte[] fileBytes;
        foreach (var file in mailRequest.Attachments)
        {
          if (file.Length > 0)
          {
            using (var ms = new MemoryStream())
            {
              file.CopyTo(ms);
              fileBytes = ms.ToArray();
            }

            builder.Attachments.Add(file.FileName, fileBytes, ContentType.Parse(file.ContentType));
          }
        }
      }

      builder.HtmlBody = mailRequest.Body;
      email.Body = builder.ToMessageBody();
      return email;
    }

    private async Task SendMessageUsingMailKit(MimeMessage email)
    {
      using var smtp = new SmtpClient();

      smtp.ServerCertificateValidationCallback = (s, c, h, e) => true;
      smtp.Connect("smtp.gmail.com", 587, SecureSocketOptions.StartTlsWhenAvailable);
      smtp.Authenticate(mailSettings.MailFrom, mailSettings.Password);

      //smtp.Connect(mailSettings.SmtpServer, mailSettings.Port, SecureSocketOptions.StartTls);
      await smtp.SendAsync(email);
      smtp.Disconnect(true);
    }

    private Task SendMessageUsingNetMail(MimeMessage mailMessage)
    {
      try
      {
        var mail = new System.Net.Mail.MailMessage();

        var smtpServer = new System.Net.Mail.SmtpClient("smtp.gmail.com");

        mail.From = new MailAddress("joe.a.marco@gmail.com");

        var to_address = @"townj474@gmail.com";

        mail.To.Add(to_address);

        mail.Subject = mailMessage.Subject; // "Test Mail - 1";

        mail.Body = mailMessage.HtmlBody; // "mail with attachment";

        var attachmentFiles = mailMessage.Attachments; // @".\Data\YieldCurve_20220905_110707.xlsx";

        foreach (var attachmentFile in attachmentFiles)
        {
          var attachment = new System.Net.Mail.Attachment(attachmentFile.ToString());

          mail.Attachments.Add(attachment);
        }

        smtpServer.Port = mailSettings.Port;

        // vkl ucw ugv rlt slx o
        // https://evermap.com/Tutorial_ADM_UsingAppPasswordsGmail.asp#:~:text=This%20method%20requires%20App%20Passwords,2%2DStep%20Verification%20turned%20on.

        smtpServer.Credentials = new System.Net.NetworkCredential(mailSettings.Username, mailSettings.Password);

        smtpServer.EnableSsl = true;

        smtpServer.Send(mail);

        Debug.WriteLine(@"mail Send");
      }
      catch (Exception ex)
      {
        Debug.WriteLine(ex.ToString());
        throw ex;
      }

      return Task.CompletedTask;
    }
  }
}
