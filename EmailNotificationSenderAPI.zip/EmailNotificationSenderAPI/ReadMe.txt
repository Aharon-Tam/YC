https://www.c-sharpcorner.com/article/send-email-using-asp-net-core-5-web-api/
