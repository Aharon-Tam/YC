﻿namespace WebSocketClient
{
  // https://www.youtube.com/watch?v=BNZLQCmL1mA&list=PLx3k0RGeXZ_wZ_gYpYXfH6FTK7e0cDL0k

  using System;
  using System.Threading;

  using WebSocketSharp;

  internal class ClientProgram
  {
    static void Main(string[] args)
    {
      var serverUrl = @"ws://localhost:8056";

      //const string SingleClientEchoBack = "/Echo";
      const string AllClientEchoBack = "/EchoAll";

      var clientUrl = $"{serverUrl}{AllClientEchoBack}";

      Console.WriteLine($"Client connecting on {clientUrl} ...");

      using (var ws = new WebSocket(clientUrl))
      {
        ws.OnMessage += (sender, eventArgs) =>
          {
            Console.WriteLine($"Received from Server: ==> {eventArgs.Data}");
          };

        try
        {
          while (true)
          {
            ws.Connect();

            if (ws.IsAlive)
            {
              ws.Send("hello Mr. Server");
              ws.Close();

              break;
            }
            else
            {
              Thread.Sleep(2000);
            }
          }
        }
        catch (Exception excep)
        {
          Console.WriteLine(excep);
        }

        Console.ReadKey();
      }
    }
  }
}
