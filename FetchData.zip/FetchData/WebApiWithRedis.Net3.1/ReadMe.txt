﻿https://www.ezzylearning.net/tutorial/distributed-caching-in-asp-net-core-using-redis-cache

1. !Scaffold-DbContext: The term ‘Scaffold-DbContext’ is not recognized as the name of a cmdlet, function
   Install-Package Microsoft.EntityFrameworkCore.Tools  - https://www.thecodebuzz.com/scaffold-dbcontext-is-not-recognized-as-the-name-of-a-cmdlet/
2. Scaffold-DbContext -Connection "Server=.; Database= KalmanDB; Trusted_Connection=True; MultipleActiveResultSets=true;" -Provider Microsoft.EntityFrameworkCore.SqlServer -OutputDir "Models" -ContextDir "Data" -Context "KalmanDbContext" -Tables "KalmanFeed"
3. !Could not load assembly 'React_HelloWorld_MVC'. Ensure it is referenced by the startup project 'WebApiWithRedis'
4. Microsoft.EntityFrameworkCore.Design