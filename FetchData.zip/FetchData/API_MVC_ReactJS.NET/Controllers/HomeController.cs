﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace React_HelloWorld_MVC.Controllers
{
  // article
  // https://www.aspsnippets.com/Articles/ReactJS-Fetch-Data-from-API-and-display-in-Table.aspx
  public class HomeController : Controller
  {
    // GET: Home
    public ActionResult Index()
    {
      return View();
    }
  }
}