﻿using System;

namespace WebSocketServer
{
  using WebSocketSharp;
  using WebSocketSharp.Server;

  internal class ServerProgram
  {
    static void Main(string[] args)
    {
      const string ServerUrl = @"ws://localhost:8056";

      const string EchoToOne = "/Echo";
      const string EchoToAll = "/EchoAll";

      try
      {
        var wss = new WebSocketServer(ServerUrl);

        wss.AddWebSocketService<EchoToOneClient>(EchoToOne);
        wss.AddWebSocketService<EchoToAllClient>(EchoToAll);

        wss.Start();

        var oneClientUrl = $"{ServerUrl}{EchoToOne}";
        var allClientUrl = $"{ServerUrl}{EchoToAll}";

        Console.WriteLine($"Web Socket Server has started Service for one Client on {oneClientUrl} ...");
        Console.WriteLine($"Web Socket Server has started Service for all Clients on  {allClientUrl} ...");

        Console.ReadKey();

        wss.Stop();
      }
      catch (Exception excep)
      {
        Console.WriteLine(excep);
      }
    }
  }

  public class EchoToOneClient : WebSocketBehavior
  {
    protected override void OnMessage(MessageEventArgs e)
    {
      Console.WriteLine($"Received message from client: ==> {e.Data}");
      Send(e.Data);
    }
  }

  public class EchoToAllClient : WebSocketBehavior
  {
    protected override void OnMessage(MessageEventArgs e)
    {
      Console.WriteLine($"Received message from client: ==> {e.Data}");
      Sessions.Broadcast(e.Data);
    }
  }
}
