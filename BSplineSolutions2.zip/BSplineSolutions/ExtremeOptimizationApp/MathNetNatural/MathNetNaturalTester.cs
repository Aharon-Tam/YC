﻿namespace BSplineImplementations.MathNetNatural
{
  using System;
  using System.Diagnostics;
  using System.Drawing;

  using BSplineImplementations.LinearCubic;
  using BSplineImplementations.RosettaFitter;

  using global::MathNet.Numerics.Interpolation;
  using global::MathNet.Numerics.LinearAlgebra.Double;

  using ScottPlot;

  public class MathNetNaturalTester
  {
    public static void RunCubic()
    {
      // https://rosettacode.org/wiki/Polynomial_regression#C#

      //double[] xValues = { 1, 2, 3, 4, 5, 6 };
      //double[] yValues = { 11, 13, 14, 13, 14, 12 };

      // https://stackoverflow.com/questions/68198149/using-mathnet-library-to-interpolate-along-a-cubic-spline

      var xValues = new[] { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0 };
      var yValues = new[] { 1.0, 6.0, 17.0, 34.0, 57.0, 86.0, 121.0, 162.0, 209.0, 262.0, 321.0 };

      var wrapper = new MathNetNaturalWrapper(xValues, yValues);

      var result = wrapper.InterpolateXY(xValues, yValues, 200);

      // Plot the original vs. interpolated data
      var plt = new ScottPlot.Plot(600, 400);
      plt.AddScatter(xValues, yValues, label: "original", markerSize: 7);
      plt.AddScatter(result.xsOut, result.ysOut, label: "interpolated", markerSize: 3);
      plt.AddScatter(result.xsOut, result.d1Out, label: "tangent", markerSize: 3, color: Color.Purple);
      plt.AddScatter(result.xsOut, result.d2Out, label: "convexity", markerSize: 3, color: Color.OrangeRed);
      plt.Legend(location: Alignment.UpperLeft);

      var now = DateTime.Now;
      var timestampdate = now.ToString("yyyyMMdd_hhmmss");
      var root = @"C:\CS\Spline\Data";
      var pngFile = $@"{root}\MathNetNatural_{timestampdate}.png";
      plt.SaveFig(pngFile);

      pngFile.ShowPhoto();
    }

    public static void RunNaturalCubic1()
    {
      // https://stackoverflow.com/questions/34206611/calculating-a-derivative-with-math-net-c-sharp

      const int column_width = 12;

      var xvec = new DenseVector(new double[] { 0.0, 1.0, 2.0, 3.0, 4.0 });
      var yvec = new DenseVector(new double[] { 3.0, 2.7, 2.3, 1.6, 0.2 });
      Debug.WriteLine("Input Data Table");
      Debug.WriteLine($"{"x",column_width} {"y",column_width}");
      for (int i = 0; i < xvec.Count; i++)
      {
        Debug.WriteLine($"{xvec[i],column_width:G5} {yvec[i],column_width:G5}");
      }
      Debug.WriteLine(" ");
      var cs = CubicSpline.InterpolateNatural(xvec, yvec);
      var min_max = cs.Extrema();

      var x = new DenseVector(15);
      var y = new DenseVector(x.Count);
      var dydx = new DenseVector(x.Count);
      var d2ydx2 = new DenseVector(x.Count);
      Debug.WriteLine("Interpoaltion Results Table");
      Debug.WriteLine($"{"x",column_width} {"y",column_width} {"dy/dx",column_width}");
      for (int i = 0; i < x.Count; i++)
      {
        x[i] = (4.0 * i) / (x.Count - 1);
        y[i] = cs.Interpolate(x[i]);
        dydx[i] = cs.Differentiate(x[i]);
        d2ydx2[i] = cs.Differentiate2(x[i]);
        Debug.WriteLine($"{x[i],column_width:G5} {y[i],column_width:G5} {dydx[i],column_width:G5}");
      }

      ////

      double[] xValues = { 1, 2, 3, 4, 5, 6 };
      double[] yValues = { 11, 13, 14, 13, 14, 12 };

      // https://stackoverflow.com/questions/34206611/calculating-a-derivative-with-math-net-c-sharp
      // https://stackoverflow.com/questions/68198149/using-mathnet-library-to-interpolate-along-a-cubic-spline

      var cubicSplineWrapper = new MathNetNaturalWrapper(xValues, yValues);

      var result = cubicSplineWrapper.InterpolateXY(xValues, yValues, 200);

      // Plot the original vs. interpolated data
      var plt = new ScottPlot.Plot(600, 400);
      plt.AddScatter(xValues, yValues, label: "original", markerSize: 7);
      plt.AddScatter(result.xsOut, result.ysOut, label: "interpolated", markerSize: 3);
      plt.Legend();

      var now = DateTime.Now;
      var timestampdate = now.ToString("yyyyMMdd_hhmmss");
      var root = @"C:\CS\Spline\Data";
      var pngFile = $@"{root}\MathNetTest_{timestampdate}.png";
      plt.SaveFig(pngFile);

      pngFile.ShowPhoto();
    }
  }
}
