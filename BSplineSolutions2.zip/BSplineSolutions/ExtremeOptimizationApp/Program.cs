﻿namespace BSplineImplementations
{
  using System;

  using BSplineImplementations.MathNet;
  using BSplineImplementations.MathNetNatural;
  using BSplineImplementations.RosettaFitter;
  using BSplineImplementations.TinySpline;

  internal class Program
  {
    static void Main(string[] args)
    {
      MathNetNaturalTester.RunCubic();

      //-- SplineIncreasingTester.RunSplineOnIncreasing();

      //-- RosettaFitterTester.RunPolynomial();

      //-- TinySplineTester.RunSpline();

      //-- MathNetTester.RunAkimaCubic();

      //-- LinearCubicTester.RunLinear();

      //-- LinearCubicTester.RunCubic();

      //-- CubicHardenTester.RunTest();

      //-- CubicSplines.QuickStart();

      Console.ReadKey();
    }
  }
}
