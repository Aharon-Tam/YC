﻿namespace BSplineImplementations.RosettaFitter
{
  using System;
  using System.Drawing;

  using BSplineImplementations.LinearCubic;
  using BSplineImplementations.MathNet;

  using ScottPlot;

  public class RosettaFitterTester
  {
    public static void RunPolynomial()
    {
      // https://rosettacode.org/wiki/Polynomial_regression#C#

      //double[] xValues = { 1, 2, 3, 4, 5, 6 };
      //double[] yValues = { 11, 13, 14, 13, 14, 12 };

      // https://stackoverflow.com/questions/68198149/using-mathnet-library-to-interpolate-along-a-cubic-spline

      var xValues = new[] { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0 };
      var yValues = new[] { 1.0, 6.0, 17.0, 34.0, 57.0, 86.0, 121.0, 162.0, 209.0, 262.0, 321.0 };

      var rosettaWrapper = new RosettaWrapper(xValues, yValues);

      const int degree = 3;
      var result = rosettaWrapper.InterpolateXY(xValues, yValues, degree, 200);

      // Plot the original vs. interpolated data
      var plt = new ScottPlot.Plot(600, 400);
      plt.AddScatter(xValues, yValues, label: "original", markerSize: 7);
      plt.AddScatter(result.xsOut, result.ysOut, label: "interpolated", markerSize: 3);
      plt.AddScatter(result.xsOut, result.d1Out, label: "tangent", markerSize: 3, color: Color.GreenYellow);
      plt.AddScatter(result.xsOut, result.d2Out, label: "convexity", markerSize: 3, color: Color.Aqua);
      plt.Legend(location: Alignment.UpperLeft);

      var now = DateTime.Now;
      var timestampdate = now.ToString("yyyyMMdd_hhmmss");
      var root = @"C:\CS\Spline\Data";
      var pngFile = $@"{root}\RosettaFitter_{timestampdate}.png";
      plt.SaveFig(pngFile);

      pngFile.ShowPhoto();
    }
  }
}
