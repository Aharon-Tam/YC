﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BSplineImplementations.TinySpline
{
  using System.Linq;

  using global::TinySpline;

  internal class SplineIncreasingWrapper
  {
    // https://github.com/msteinbeck/tinyspline/blob/master/examples/cxx/time_series.cpp

    private readonly BSpline bSpline;
    public SplineIncreasingWrapper(double[] xValues, double[] yValues, bool bisec = false)
    {
      if (bisec)
      {
        var points = new List<double>();

        for (var ii = 0; ii < xValues.Length; ii++)
        {
          points.Add(xValues[ii]);
          points.Add(yValues[ii]);
        }

        bSpline = BSpline.InterpolateCubicNatural(points, 2);

        var times = new double[] { 1.0, 1.5, 2.0, 2.5, 3.0 };

        foreach (var t in times)
        {
          DeBoorNet net = bSpline.Bisect(t);
          var result = net.Result;

          Console.WriteLine($"t = {result[0]}, p = ({result[1]})");
        }

        Console.WriteLine();

        //Console.WriteLine($"t = {result[0]}, p = ({result[1]}, {result[2]}, {result[3]})");
        //DeBoorNet net = bSpline.Bisect(1850);
        //std::vector<tinyspline::real> result = net.result();
        //std::cout << "t = " << result[0] << ", p = (" << result[1] << ", "
        //  << result[2] << ", " << result[3] << ")" << std::endl;
      }
      else
      {
        uint numControlPoints = (uint)xValues.Length;
        bSpline = new BSpline(numControlPoints); // numControlPoints: 7, dimension: 2

        // Setup control points.
        IList<double> controlPoints = bSpline.ControlPoints;
        var k = 0;
        for (var i = 0; i < numControlPoints; i++)
        {
          var xVal = xValues[i];
          var yVal = yValues[i];
          controlPoints[k++] = xVal;
          controlPoints[k++] = yVal;
        }
        bSpline.ControlPoints = controlPoints;

        //var times = new double[] { 1.0, 1.5, 2.0, 2.5, 3.0 };

        //foreach (var t in times)
        //{
        //  DeBoorNet net = bSpline.Bisect(t);
        //  var result = net.Result;

        //  Console.WriteLine($"t = {result[0]}, p = ({result[1]})");
        //}

        //Console.WriteLine();

        //
        var u = 0.4;
        Console.WriteLine($"=== BSpline-2D Evaluate `spline` at u = {u} ===");

        IList<double> result2D = bSpline.Eval(u).Result;
      }
    }

    public (double[] xsOut, double[] ysOut, double[] d1Out, double[] d2Out) InterpolateXY(double[] xsInput, double[] ysInput, int count)
    {
      if (xsInput is null || ysInput is null || xsInput.Length != ysInput.Length)
        throw new ArgumentException($"{nameof(xsInput)} and {nameof(ysInput)} must have same length");

      int inputPointCount = xsInput.Length;
      double[] inputDistances = new double[inputPointCount];
      for (var i = 1; i < inputPointCount; i++)
      {
        double dx = xsInput[i] - xsInput[i - 1];
        double dy = ysInput[i] - ysInput[i - 1];
        double distance = Math.Sqrt(dx * dx + dy * dy);
        inputDistances[i] = inputDistances[i - 1] + distance;
      }

      double meanDistance = inputDistances.Last() / (count - 1);
      double[] evenDistances = Enumerable.Range(0, count).Select(x => x * meanDistance).ToArray();
      double[] xsOut = Interpolate(inputDistances, xsInput, evenDistances);

      BSpline tangent = bSpline.Derive(1);
      BSpline convexity = bSpline.Derive(2);

      double[] ysOut = new double[count];
      double[] d1Out = new double[count];
      double[] d2Out = new double[count];

      for (var j = 0; j < count; j++)
      {
        var xPnt = xsOut[j];
        DeBoorNet xyNet = bSpline.Bisect(xPnt);
        var yVal = xyNet.Result[1];
        ysOut[j] = yVal;
        var d1Vec2 = tangent.Bisect(xPnt).ResultVec2();
        var d2Vec2 = convexity.Bisect(xPnt).ResultVec2();
        //d1Out[j] = d1Val;
        //d2Out[j] = d2Val;
      }

      return (xsOut, ysOut, d1Out, d2Out);
    }

    private static double[] Interpolate(double[] xOrig, double[] yOrig, double[] xInterp)
    {
      (double[] a, double[] b) = FitMatrix(xOrig, yOrig);

      double[] yInterp = new double[xInterp.Length];
      for (int i = 0; i < yInterp.Length; i++)
      {
        int j;
        for (j = 0; j < xOrig.Length - 2; j++)
          if (xInterp[i] <= xOrig[j + 1])
            break;

        double dx = xOrig[j + 1] - xOrig[j];
        double t = (xInterp[i] - xOrig[j]) / dx;
        double y = (1 - t) * yOrig[j] + t * yOrig[j + 1] +
                   t * (1 - t) * (a[j] * (1 - t) + b[j] * t);
        yInterp[i] = y;
      }

      return yInterp;
    }

    private static (double[] a, double[] b) FitMatrix(double[] x, double[] y)
    {
      int n = x.Length;
      double[] a = new double[n - 1];
      double[] b = new double[n - 1];
      double[] r = new double[n];
      double[] A = new double[n];
      double[] B = new double[n];
      double[] C = new double[n];

      double dx1, dx2, dy1, dy2;

      dx1 = x[1] - x[0];
      C[0] = 1.0f / dx1;
      B[0] = 2.0f * C[0];
      r[0] = 3 * (y[1] - y[0]) / (dx1 * dx1);

      for (int i = 1; i < n - 1; i++)
      {
        dx1 = x[i] - x[i - 1];
        dx2 = x[i + 1] - x[i];
        A[i] = 1.0f / dx1;
        C[i] = 1.0f / dx2;
        B[i] = 2.0f * (A[i] + C[i]);
        dy1 = y[i] - y[i - 1];
        dy2 = y[i + 1] - y[i];
        r[i] = 3 * (dy1 / (dx1 * dx1) + dy2 / (dx2 * dx2));
      }

      dx1 = x[n - 1] - x[n - 2];
      dy1 = y[n - 1] - y[n - 2];
      A[n - 1] = 1.0f / dx1;
      B[n - 1] = 2.0f * A[n - 1];
      r[n - 1] = 3 * (dy1 / (dx1 * dx1));

      double[] cPrime = new double[n];
      cPrime[0] = C[0] / B[0];
      for (int i = 1; i < n; i++)
        cPrime[i] = C[i] / (B[i] - cPrime[i - 1] * A[i]);

      double[] dPrime = new double[n];
      dPrime[0] = r[0] / B[0];
      for (int i = 1; i < n; i++)
        dPrime[i] = (r[i] - dPrime[i - 1] * A[i]) / (B[i] - cPrime[i - 1] * A[i]);

      double[] k = new double[n];
      k[n - 1] = dPrime[n - 1];
      for (int i = n - 2; i >= 0; i--)
        k[i] = dPrime[i] - cPrime[i] * k[i + 1];

      for (int i = 1; i < n; i++)
      {
        dx1 = x[i] - x[i - 1];
        dy1 = y[i] - y[i - 1];
        a[i - 1] = k[i - 1] * dx1 - dy1;
        b[i - 1] = -k[i] * dx1 + dy1;
      }

      return (a, b);
    }
  }
}
