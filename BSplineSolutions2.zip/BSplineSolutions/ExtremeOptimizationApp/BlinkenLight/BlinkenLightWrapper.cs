﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BSplineImplementations.BlinkenLight
{
  using Blinkenlights.Splines;

  internal class BlinkenLightWrapper
  {
    private double[] xValues;

    private double[] yValues;

    // https://bitbucket.org/pgrebenc/b-spline/src/master/Source/Blinkenlights.Splines.Tests/BSplineTests.cs

    public BlinkenLightWrapper(double[] xValues, double[] yValues)
    {
      this.xValues = xValues;
      this.yValues = yValues;
    }

    public void Interpolate_ForUnclampedKnotVector_GeneratesCorrectValues()
    {
      double[][] points = { new[] { -1.0, 0.0 }, new[] { -0.5, 0.5 }, new[] { 0.5, -0.5 }, new[] { 1.0, 0.0 } };

      var degree = 2;

      var actual = new List<double[]>();
      for (double t = 0; t < 1; t += 0.01)
      {
        var point = BSpline.Interpolate(t, degree, points, null, null, null);
        actual.Add(point);
      }
    }

    public void Interpolate_ForClampedKnotVector_GeneratesCorrectValues()
    {
      double[][] points = { new[] { -1.0, 0.0 }, new[] { -0.5, 0.5 }, new[] { 0.5, -0.5 }, new[] { 1.0, 0.0 } };

      var degree = 2;

      double[] knots = { 0, 0, 0, 1, 2, 2, 2 };

      var actual = new List<double[]>();
      for (double t = 0; t < 1; t += 0.01)
      {
        var point = BSpline.Interpolate(t, degree, points, knots, null, null);
        actual.Add(point);
      }

    }

    public void Interpolate_ForClosedCurves_GeneratesCorrectValues()
    {
      double[][] points =
        {
          new[] { -1.0, 0.0 }, new[] { -0.5, 0.5 }, new[] { 0.5, -0.5 }, new[] { 1.0, 0.0 }, new[] { -1.0, 0.0 },
          new[] { -0.5, 0.5 }, new[] { 0.5, -0.5 }
        };

      var degree = 2;

      double[] knots = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

      var actual = new List<double[]>();
      for (double t = 0; t < 1; t += 0.01)
      {
        var point = BSpline.Interpolate(t, degree, points, knots, null, null);
        actual.Add(point);
      }

    }

    public void Interpolate_ForNonUniformRational_GeneratesCorrectValues()
    {
      double[][] points =
        {
          new[] { 0.0, -0.5 }, new[] { -0.5, -0.5 }, new[] { -0.5, 0.0 }, new[] { -0.5, 0.5 }, new[] { 0.0, 0.5 },
          new[] { 0.5, 0.5 }, new[] { 0.5, 0.0 }, new[] { 0.5, -0.5 }, new[] { 0.0, -0.5 }
        };

      double[] knots =
        {
          0.0, 0.0, 0.0, 1.0 / 4.0, 1.0 / 4.0, 1.0 / 2.0, 1.0 / 2.0, 3.0 / 4.0, 3.0 / 4.0, 1.0, 1.0, 1.0
        };

      var w = Math.Pow(2, 0.5) / 2;
      double[] weights = { 1, w, 1, w, 1, w, 1, w, 1 };

      var degree = 2;

      var actual = new List<double[]>();
      for (double t = 0; t < 1; t += 0.01)
      {
        var point = BSpline.Interpolate(t, degree, points, knots, weights, null);
        actual.Add(point);
      }

    }
  }
}

