﻿namespace LinearCubicInterpolations
{
  using System.Linq;

  abstract class AbstractInterpolation : IInterpolate
  {
    private readonly double[] x;
    private readonly double[] y;

    public abstract double? Interpolate(double p);

    protected AbstractInterpolation(double[] x, double[] y)
    {
      int xLength = x.Length;
      if (xLength == y.Length && xLength > 1 && x.Distinct().Count() == xLength)
      {
        this.x = x;
        this.y = y;
      }
    }

    // cubic spline relies on the abscissa values to be sorted
    protected AbstractInterpolation(double[] x, double[] y, bool checkSorted = true)
    {
      int xLength = x.Length;
      if (checkSorted)
      {
        if (xLength == y.Length && xLength > 1 && x.Distinct().Count() == xLength && Enumerable.SequenceEqual(LinearCubicInterpolations.Extensions.SortedList(x), x.ToList()))
        {
          this.x = x;
          this.y = y;
        }
      }
      else
      {
        if (xLength == y.Length && xLength > 1 && x.Distinct().Count() == xLength)
        {
          this.x = x;
          this.y = y;
        }
      }
    }

    public double[] X => x;

    public double[] Y => y;
  }
}
