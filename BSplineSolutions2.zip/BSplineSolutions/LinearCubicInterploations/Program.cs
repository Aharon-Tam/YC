﻿namespace LinearCubicInterpolations
{
  using System;
  using System.Collections.Generic;
  using System.Linq;

  internal class Program
  {
    // https://pages.mtu.edu/~shene/COURSES/cs3621/NOTES/spline/B-spline/bspline-curve-coef.html
    // https://codefying.com/2015/06/07/linear-and-cubic-spline-interpolation/

    static void Main(string[] args)
    {
      // code relies on abscissa values to be sorted
      // there is a check for this condition, but no fix
      // f(x) = 1/(1+x^2)*sin(x)
      double[] ex = { -5, -3, -2, -1, 0, 1, 2, 3, 5 };
      double[] ey = { 0.036882, -0.01411, -0.18186, -0.42074, 0, 0.420735, 0.181859, 0.014112, -0.03688 };
      double[] p = { -5, -4.5, -4, -3.5, -3.2, -3, -2.8, -2.1, -1.5, -1, -0.8, 0, 0.65, 1, 1.3, 1.9, 2.6, 3.1, 3.5, 4, 4.5, 5 };

      var linearInterpolation = new LinearInterpolation(ex, ey);
      var cubicSplineInterpolation = new CubicSplineInterpolation(ex, ey);

      Console.WriteLine("Linear Interpolation:");

      foreach (double pp in p)
      {
        //Console.Write($"{linearInterpolation.Interpolate(pp)}, ");
        Console.WriteLine($"{linearInterpolation.Interpolate(pp)}");
      }
      Console.WriteLine();

      Console.WriteLine("Cubic Spline Interpolation:");
      foreach (double pp in p)
      {
        //Console.Write($"{cubicSplineInterpolation.Interpolate(pp)}, ");
        Console.WriteLine($"{cubicSplineInterpolation.Interpolate(pp)}");
      }
      Console.WriteLine();

      Console.ReadLine();
    }
  }
}
