﻿using System;

namespace DataTableToExcel
{
  using System.Data;
  using System.Diagnostics;

  using SwiftExcel;

  internal class Program
  {
    static void Main(string[] args)
    {
      var targetFile = @$"C:\CS\Spline\Data\DataTableData.xlsx";

      var tbl = new DataTable();
      tbl.Columns.Add("Column1");
      tbl.Columns.Add("Column2");
      tbl.Columns.Add("Column3");
      tbl.Rows.Add("Item1", "Item2", "Item3");

      var seet = new Sheet();
      seet.Name = "YieldCurve";
      var fileName = "C:\\CS\\Spline\\Data\\temp\\test.xlsx";
      WriteExcel(fileName, seet, tbl);

      OpenMicrosoftExcel(fileName);
    }

    private static void OpenMicrosoftExcel(string fileName)
    {
      var startInfo = new ProcessStartInfo();
      startInfo.FileName = @"C:\Program Files (x86)\Microsoft Office\root\Office16\EXCEL.EXE";
      startInfo.Arguments = fileName;
      Process.Start(startInfo);
    }

    private static void WriteExcel(string fileName, Sheet seet, DataTable tbl)
    {
      using var ew = new ExcelWriter(fileName, seet);
      // column headings
      for (var j = 1; j <= tbl.Columns.Count; j++)
      {
        var columnName = tbl.Columns[j-1].ColumnName;

        ew.Write(columnName, j, 1);
      }
    }
  }
}
