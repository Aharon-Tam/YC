namespace WindowsApplication1
{
  using System;
  using System.Drawing;
  using System.Windows.Forms;

  public partial class Form1 : Form
  {
    #region Fields

    public int no_of_points;

    public point[] pt = new point[6];

    public double[] splinex = new double[1001];

    public double[] spliney = new double[1001];

    private int[] a1 = new int[12];

    private int[] b1 = new int[12];

    #endregion

    #region Constructors and Destructors

    public Form1()
    {
      InitializeComponent();
    }

    #endregion

    #region Public Methods and Operators

    // calculating the values using the algorithm 
    public void bsp(point p1, point p2, point p3, point p4, int divisions)
    {
      var a = new double[5];
      var b = new double[5];
      a[0] = (-p1.x + 3 * p2.x - 3 * p3.x + p4.x) / 6.0;
      a[1] = (3 * p1.x - 6 * p2.x + 3 * p3.x) / 6.0;
      a[2] = (-3 * p1.x + 3 * p3.x) / 6.0;
      a[3] = (p1.x + 4 * p2.x + p3.x) / 6.0;
      b[0] = (-p1.y + 3 * p2.y - 3 * p3.y + p4.y) / 6.0;
      b[1] = (3 * p1.y - 6 * p2.y + 3 * p3.y) / 6.0;
      b[2] = (-3 * p1.y + 3 * p3.y) / 6.0;
      b[3] = (p1.y + 4 * p2.y + p3.y) / 6.0;

      splinex[0] = a[3];
      spliney[0] = b[3];

      int i;
      for (i = 1; i <= divisions - 1; i++)
      {
        var t = Convert.ToSingle(i) / Convert.ToSingle(divisions);
        splinex[i] = (a[2] + t * (a[1] + t * a[0])) * t + a[3];
        spliney[i] = (b[2] + t * (b[1] + t * b[0])) * t + b[3];
      }
    }

    #endregion

    #region Methods

    // At each mousedown event the the no of points is calculated if the value is more than 3
    //then the curve is drawn
    private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
    {
      if (no_of_points > 3)
      {
        pt[0] = pt[1];
        pt[1] = pt[2];
        pt[2] = pt[3];
        pt[3].setxy(e.X, e.Y);
        var temp = Math.Sqrt(Math.Pow(pt[2].x - pt[1].x, 2F) + Math.Pow(pt[2].y - pt[1].y, 2F));
        var interpol = Convert.ToInt32(temp);
        bsp(pt[0], pt[1], pt[2], pt[3], interpol);
        int i;
        var width = 2;
        var g = pictureBox1.CreateGraphics();
        var cl = Color.Blue;
        int x, y;
        // the lines are drawn
        for (i = 0; i <= interpol - 1; i++)
        {
          x = Convert.ToInt32(splinex[i]);
          y = Convert.ToInt32(spliney[i]);
          g.DrawLine(new Pen(cl, width), x - 1, y, x + 1, y);
          g.DrawLine(new Pen(cl, width), x, y - 1, x, y + 1);
        }
      }
      else
      {
        pt[no_of_points].setxy(e.X, e.Y);
      }

      no_of_points = no_of_points + 1;
    }

    // Prints a dot at the place whrere the mouseup event occurs 
    private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
    {
      var g = pictureBox1.CreateGraphics();
      var cl = Color.Black;
      g.DrawLine(new Pen(cl, 2), e.X, e.Y, e.X + 1, e.Y + 1);
    }

    #endregion

    public struct point
    {
      #region Fields

      public int x;

      public int y;

      #endregion

      #region Public Methods and Operators

      public void setxy(int i, int j)
      {
        x = i;
        y = j;
      }

      #endregion
    }
  }
}