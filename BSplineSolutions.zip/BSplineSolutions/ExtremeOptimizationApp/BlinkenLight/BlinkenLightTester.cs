﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BSplineImplementations.BlinkenLight
{
  internal class BlinkenLightTester
  {
  }
}
