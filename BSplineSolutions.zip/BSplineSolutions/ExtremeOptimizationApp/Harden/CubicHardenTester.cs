﻿namespace BSplineImplementations.Harden
{
  using System;
  using System.Diagnostics;

  public class CubicHardenTester
  {
    public static void RunTest()
    {
      double[] xValues = { 1, 2, 3, 4, 5, 6 };
      double[] yValues = { 11, 13, 14, 13, 14, 12 };

      // generate sample data using a random walk
      int pointCount = 6;
      double[] xs1 = new double[pointCount];
      double[] ys1 = new double[pointCount];
      for (int i = 0; i < pointCount; i++)
      {
        xs1[i] = xValues[i];
        ys1[i] = yValues[i];
      }

      // Use cubic interpolation to smooth the original data
      (double[] xs2, double[] ys2) = CubicHarden.InterpolateXY(xs1, ys1, 200);

      // Plot the original vs. interpolated data
      var plt = new ScottPlot.Plot(600, 400);
      plt.AddScatter(xs1, ys1, label: "original", markerSize: 7);
      plt.AddScatter(xs2, ys2, label: "interpolated", markerSize: 3);
      plt.Legend();

      var now = DateTime.Now;
      var timestampdate = now.ToString("yyyyMMdd_hhmmss");
      var root = @"C:\CS\Spline\Data";
      var filePathName = $@"{root}\HardenCubicTest_{timestampdate}.png";
      plt.SaveFig(filePathName);

      ShowPhoto(filePathName);
      //Process.Start(filePathName);

      //var paint = @"C:\WINDOWS\system32\mspaint.exe";
      //Process.Start(paint, filePathName);
    }

    public static void RunOnRandom()
    {
      // generate sample data using a random walk
      Random rand = new Random(1268);
      int pointCount = 20;
      double[] xs1 = new double[pointCount];
      double[] ys1 = new double[pointCount];
      for (int i = 1; i < pointCount; i++)
      {
        xs1[i] = xs1[i - 1] + rand.NextDouble() - .5;
        ys1[i] = ys1[i - 1] + rand.NextDouble() - .5;
      }

      // Use cubic interpolation to smooth the original data
      (double[] xs2, double[] ys2) = CubicHarden.InterpolateXY(xs1, ys1, 200);

      // Plot the original vs. interpolated data
      var plt = new ScottPlot.Plot(600, 400);
      plt.AddScatter(xs1, ys1, label: "original", markerSize: 7);
      plt.AddScatter(xs2, ys2, label: "interpolated", markerSize: 3);
      plt.Legend();

      var now = DateTime.Now;
      var timestampdate = now.ToString("yyyyMMdd_hhmmss");
      var root = @"C:\CS\Spline\Data";
      var filePathName = $@"{root}\CubicInterpolation_{timestampdate}.png";
      plt.SaveFig(filePathName);

      ShowPhoto(filePathName);
      //Process.Start(filePathName);

      //var paint = @"C:\WINDOWS\system32\mspaint.exe";
      //Process.Start(paint, filePathName);
    }

    public static void ShowPhoto(string tempFileName)
    {
      string path = Environment.GetFolderPath(
        Environment.SpecialFolder.ProgramFiles);

      // create our startup process and argument
      var psi = new ProcessStartInfo(
        "rundll32.exe",
        $"\"{(Environment.Is64BitOperatingSystem ? path.Replace(" (x86)", "") : path)}{@"\Windows Photo Viewer\PhotoViewer.dll"}\", ImageView_Fullscreen {tempFileName}");

      psi.UseShellExecute = false;

      var viewer = Process.Start(psi);

      // cleanup when done...
      viewer.EnableRaisingEvents = true;
      viewer.Exited += (o, args) =>
        {
          //-- File.Delete(tempFileName);
        };
    }
  }
}
