﻿namespace BSplineImplementations
{
  using System;

  using BSplineImplementations.MathNet;
  using BSplineImplementations.TinySpline;

  internal class Program
  {
    static void Main(string[] args)
    {
      TinySplineTester.RunSpline();

      //-- MathNetTester.RunAkimaCubic();

      //-- LinearCubicTester.RunLinear();

      //-- LinearCubicTester.RunCubic();

      //-- CubicHardenTester.RunTest();

      //-- CubicSplines.QuickStart();

      Console.ReadKey();
    }
  }
}
