﻿namespace BSplineImplementations.LinearCubic
{
  public interface IInterpolate
  {
    double? Interpolate(double p);
  }
}