﻿namespace BSplineImplementations.MathNet
{
  using System;

  using BSplineImplementations.LinearCubic;

  public class MathNetTester
  {
    public static void RunAkimaCubic()
    {
      double[] xValues = { 1, 2, 3, 4, 5, 6 };
      double[] yValues = { 11, 13, 14, 13, 14, 12 };

      // https://stackoverflow.com/questions/68198149/using-mathnet-library-to-interpolate-along-a-cubic-spline

      var cubicSplineWrapper = new MathNetWrapper(xValues, yValues);

      var result = cubicSplineWrapper.InterpolateXY(xValues, yValues, 200);

      // Plot the original vs. interpolated data
      var plt = new ScottPlot.Plot(600, 400);
      plt.AddScatter(xValues, yValues, label: "original", markerSize: 7);
      plt.AddScatter(result.xsOut, result.ysOut, label: "interpolated", markerSize: 3);
      plt.Legend();

      var now = DateTime.Now;
      var timestampdate = now.ToString("yyyyMMdd_hhmmss");
      var root = @"C:\CS\Spline\Data";
      var pngFile = $@"{root}\MathNetTest_{timestampdate}.png";
      plt.SaveFig(pngFile);

      pngFile.ShowPhoto();
    }
  }
}
