﻿using System;

namespace MathNetApp
{
  using System.Diagnostics;

  using MathNet.Numerics.Interpolation;

  internal class Program
  {
    static void Main(string[] args)
    {
      // https://stackoverflow.com/questions/68198149/using-mathnet-library-to-interpolate-along-a-cubic-spline

      var xdata = new double[] { 0.083, 0.25, 0.5, 0.75, 1, 2, 4, 6, 12, 18, 24, 48, 96, 192, 240 };
      var ydata = new double[] { 3.07525894277935, 5.17525894277935, 6.67525894277935, 7.57525894277935, 8.17525894277935, 11.8, 16.1289117118988, 19.0289117118988, 24.4536527691195, 27.8383211840501, 30.2383211840501, 36.4383211840501, 44.6247410572207, 58.3094094721513, 64.6975808035617 };
      var qTrack = CubicSpline.InterpolateAkimaSorted(xdata, ydata);

      var p1 = 0.25;
      var p1Val = qTrack.Interpolate(p1);
      Console.WriteLine($"point {p1}: {p1Val}");

      var p2 = -0.01;
      var p2Val = qTrack.Interpolate(p2);
      Console.WriteLine($"point {p2}: {p2Val}");
      Console.ReadKey();
    }
  }
}
