﻿namespace LinearCubicInterpolations
{
  public interface IInterpolate
  {
    double? Interpolate(double p);
  }
}