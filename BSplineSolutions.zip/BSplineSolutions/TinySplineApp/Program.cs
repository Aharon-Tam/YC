﻿using System;

namespace TinySplineApp
{
  using System.Collections.Generic;

  using TinySpline;
  // https://github.com/msteinbeck/tinyspline/tree/master/examples
  // https://github.com/msteinbeck/tinyspline/blob/master/examples/csharp/QuickStart.cs
  // https://codefying.com/2015/06/07/linear-and-cubic-spline-interpolation/

  internal class Program
  {
    static void Main(string[] args)
    {
      // Create a cubic spline with 7 control points in 2D using
      // a clamped knot vector. This call is equivalent to:
      // BSpline spline = new BSpline(7, 2, 3, BSplineType.CLAMPED);
      var bSpline = new BSpline(7);

      // Setup control points.
      IList<double> controlPoints = bSpline.ControlPoints;
      controlPoints[0] = -1.75; // x0
      controlPoints[1] = -1.0;  // y0
      controlPoints[2] = -1.5;  // x1
      controlPoints[3] = -0.5;  // y1
      controlPoints[4] = -1.5;  // x2
      controlPoints[5] = 0.0;  // y2
      controlPoints[6] = -1.25; // x3
      controlPoints[7] = 0.5;  // y3
      controlPoints[8] = -0.75; // x4
      controlPoints[9] = 0.75; // y4
      controlPoints[10] = 0.0;  // x5
      controlPoints[11] = 0.5;  // y5
      controlPoints[12] = 0.5;  // x6
      controlPoints[13] = 0.0;  // y6
      bSpline.ControlPoints = controlPoints;

      // Evaluate `spline` at u = 0.4.
      uint idx = 0;
      var u = bSpline.KnotAt(idx);

      //var u = -1.75;
      var valDeBoorNet = bSpline.Eval(u);
      var result = valDeBoorNet.Result;
      var xx = result[0];
      var yy = result[1];

      var result2D = bSpline.Eval(u).Result;
      Console.WriteLine($"u = {u}: x = {result2D[0]}, y = {result2D[1]}");

      u = 0.4;
      Console.WriteLine($"=== BSpline-2D Evaluate `spline` at u = {u} ===");

     result2D = bSpline.Eval(u).Result;
      Console.WriteLine($"u = {u}: x = {result2D[0]}, y = {result2D[1]}");

      Console.ReadKey();
    }
  }
}
